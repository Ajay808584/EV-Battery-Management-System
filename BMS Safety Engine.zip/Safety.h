#ifndef SAFETY_H
#define SAFETY_H

#include <Arduino.h>

enum RelayState
{
    RELAY_OFF,
    RELAY_ON,
    RELAY_FAULT
};

struct SafetyData
{
    RelayState relayState;

    bool overVoltage;
    bool underVoltage;
    bool frozenReading;
    bool unrealisticJump;
    bool noisySignal;
    bool sensorInvalid;
    bool faultDetected;

    String faultId;
};

class SafetyManager
{
private:
    RelayState currentState;

    float previousVoltage;
    float voltageWindow[5];

    int windowIndex;
    int sampleCount;

    unsigned long lastChangeTime;
    unsigned long recoveryStartTime;
    unsigned long jumpSuppressionUntil;

    bool firstReading;
    bool recoveryActive;
    bool sensorActivitySeen;

    String pendingFault;
    String activeFaultId;
    int faultCount;

    // Example thresholds for a four-cell lithium-ion simulation.
    // These are not certified real-battery protection settings.
    const float OVER_VOLTAGE_TRIP = 16.8f;
    const float OVER_VOLTAGE_CLEAR = 16.5f;

    const float UNDER_VOLTAGE_TRIP = 10.0f;
    const float UNDER_VOLTAGE_CLEAR = 10.3f;

    const float CELL_OV_TRIP = 4.25f;
    const float CELL_OV_CLEAR = 4.10f;

    const float CELL_UV_TRIP = 2.50f;
    const float CELL_UV_CLEAR = 3.00f;

    const float MAX_RECOVERY_IMBALANCE = 0.50f;

    const unsigned long FROZEN_TIME = 5000UL;
    const unsigned long RECOVERY_TIME = 3000UL;
    const unsigned long JUMP_SUPPRESSION_TIME = 5000UL;

    const int FAULT_DEBOUNCE_COUNT = 2;

    bool cellsSafeForRecovery(
        const float cellVoltages[],
        int cellCount
    ) const;

    bool cellsHaveTripFault(
        const float cellVoltages[],
        int cellCount,
        bool &cellOverVoltage,
        bool &cellUnderVoltage
    ) const;

public:
    SafetyManager();

    void begin();

    SafetyData update(
        float batteryVoltage,
        const float cellVoltages[],
        int cellCount
    );

    RelayState getRelayState();
    bool isFaultActive();
};

#endif
