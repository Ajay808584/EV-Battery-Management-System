#include "Telemetry.h"

// =====================================================
// CONSTRUCTOR
// =====================================================

TelemetryManager::TelemetryManager()
{
    lastPeriodicTime = 0;

    previousRelayState = RELAY_ON;
    previousFaultState = STATE_NORMAL;

    previousFaultActive = false;
    previousImbalanceWarning = false;

    networkState = NETWORK_DISCONNECTED;

    networkStateStart = 0;
    lastWiFiAttempt = 0;
    lastRSSIUpdate = 0;

    currentRSSI = -127;

    queueHead = 0;
    queueTail = 0;
    queueCount = 0;
}

// =====================================================
// INITIALIZATION
// =====================================================

void TelemetryManager::begin()
{
    lastPeriodicTime = millis();

    previousRelayState = RELAY_ON;
    previousFaultState = STATE_NORMAL;

    previousFaultActive = false;
    previousImbalanceWarning = false;

    queueHead = 0;
    queueTail = 0;
    queueCount = 0;

    networkState = NETWORK_DISCONNECTED;

    currentRSSI = -127;

    Serial.println();
    Serial.println("================================");
    Serial.println("     TELEMETRY SYSTEM STARTED");
    Serial.println("================================");

    // Wokwi Wi-Fi network
    WiFi.mode(WIFI_STA);

    Serial.println("[NETWORK] Connecting to Wokwi Wi-Fi...");

    WiFi.begin("Wokwi-GUEST", "");

    networkState = NETWORK_CONNECTING;
    networkStateStart = millis();
    lastWiFiAttempt = millis();
}

// =====================================================
// NETWORK AVAILABLE
// =====================================================

bool TelemetryManager::isNetworkAvailable()
{
    return WiFi.status() == WL_CONNECTED;
}

// =====================================================
// NON-BLOCKING NETWORK STATE MACHINE
// =====================================================

void TelemetryManager::updateNetwork()
{
    unsigned long now = millis();

    switch (networkState)
    {
        case NETWORK_DISCONNECTED:

            if (now - lastWiFiAttempt >= WIFI_RETRY_INTERVAL)
            {
                lastWiFiAttempt = now;

                Serial.println(
                    "[NETWORK] Starting Wi-Fi reconnect"
                );

                WiFi.reconnect();

                networkState = NETWORK_CONNECTING;
                networkStateStart = now;
            }

            break;

        case NETWORK_CONNECTING:

            if (WiFi.status() == WL_CONNECTED)
            {
                networkState = NETWORK_CONNECTED;

                Serial.println("[NETWORK] Wi-Fi connected");

                Serial.print("[NETWORK] IP address: ");
                Serial.println(WiFi.localIP());

                return;
            }

            // Do not remain in CONNECTING forever.
            if (now - networkStateStart >= WIFI_RETRY_INTERVAL)
            {
                networkState = NETWORK_DISCONNECTED;

                Serial.println(
                    "[NETWORK] Wi-Fi connection timeout"
                );
            }

            break;

        case NETWORK_CONNECTED:

            if (WiFi.status() != WL_CONNECTED)
            {
                networkState = NETWORK_DISCONNECTED;

                Serial.println(
                    "[NETWORK] Wi-Fi disconnected"
                );

                return;
            }

            break;
    }
}

// =====================================================
// RSSI
// =====================================================

void TelemetryManager::updateRSSI()
{
    unsigned long now = millis();

    if (now - lastRSSIUpdate < RSSI_INTERVAL)
    {
        return;
    }

    lastRSSIUpdate = now;

    if (WiFi.status() == WL_CONNECTED)
    {
        currentRSSI = WiFi.RSSI();

        Serial.print("[NETWORK] RSSI: ");
        Serial.print(currentRSSI);
        Serial.println(" dBm");
    }
    else
    {
        currentRSSI = -127;
    }
}

// =====================================================
// EVENT NAME
// =====================================================

const char *TelemetryManager::getEventName(
    TelemetryEventType eventType
)
{
    switch (eventType)
    {
        case EVENT_PERIODIC:
            return "PERIODIC";

        case EVENT_FAULT:
            return "FAULT";

        case EVENT_FAULT_CLEARED:
            return "FAULT_CLEARED";

        case EVENT_RELAY_CHANGE:
            return "RELAY_CHANGE";

        case EVENT_STATE_CHANGE:
            return "STATE_CHANGE";

        case EVENT_IMBALANCE_WARNING:
            return "IMBALANCE_WARNING";

        default:
            return "UNKNOWN";
    }
}

// =====================================================
// ENQUEUE EVENT
// =====================================================

bool TelemetryManager::enqueueEvent(
    TelemetryEventType eventType,
    const TelemetryData &data
)
{
    /*
     * Fixed-size FIFO.
     *
     * If full, discard the oldest event so the newest
     * safety information is retained.
     */

    if (queueCount >= QUEUE_SIZE)
    {
        Serial.println(
            "[TELEMETRY] Queue full - dropping oldest event"
        );

        queueHead =
            (queueHead + 1) % QUEUE_SIZE;

        queueCount--;
    }

    QueuedTelemetryEvent &event =
        eventQueue[queueTail];

    event.eventType = eventType;
    event.timestamp = millis();

    event.packVoltage = data.packVoltage;
    event.soc = data.soc;
    event.imbalance = data.imbalance;

    event.weakestCell = data.weakestCell;
    event.strongestCell = data.strongestCell;

    event.relayState = data.relayState;
    event.faultState = data.faultState;

    event.imbalanceWarning =
        data.imbalanceWarning;

    data.faultId.toCharArray(
        event.faultId,
        sizeof(event.faultId)
    );

    data.stateName.toCharArray(
        event.stateName,
        sizeof(event.stateName)
    );

    queueTail =
        (queueTail + 1) % QUEUE_SIZE;

    queueCount++;

    Serial.print(
        "[TELEMETRY] Event queued. Depth: "
    );

    Serial.println(queueCount);

    return true;
}

// =====================================================
// DEQUEUE
// =====================================================

bool TelemetryManager::dequeueEvent(
    QueuedTelemetryEvent &event
)
{
    if (queueCount == 0)
    {
        return false;
    }

    event =
        eventQueue[queueHead];

    queueHead =
        (queueHead + 1) % QUEUE_SIZE;

    queueCount--;

    return true;
}

// =====================================================
// SEND QUEUED EVENT
// =====================================================

void TelemetryManager::sendQueuedEvent(
    const QueuedTelemetryEvent &event
)
{
    Serial.println();
    Serial.println("[TELEMETRY] QUEUED EVENT REPLAY");

    Serial.print("[TELEMETRY] Type: ");
    Serial.println(getEventName(event.eventType));

    Serial.print("[TELEMETRY] Original timestamp: ");
    Serial.println(event.timestamp);

    Serial.print("[TELEMETRY] Pack Voltage: ");
    Serial.print(event.packVoltage, 2);
    Serial.println(" V");

    Serial.print("[TELEMETRY] SOC: ");
    Serial.print(event.soc, 1);
    Serial.println(" %");

    Serial.print("[TELEMETRY] Imbalance: ");
    Serial.print(event.imbalance, 3);
    Serial.println(" V");

    Serial.print("[TELEMETRY] State: ");
    Serial.println(event.stateName);

    Serial.print("[TELEMETRY] Fault ID: ");
    Serial.println(event.faultId);

    Serial.println(
        "[TELEMETRY] Event replayed successfully"
    );
}

// =====================================================
// SEND EVENT
// =====================================================

void TelemetryManager::sendEvent(
    TelemetryEventType eventType,
    const TelemetryData &data
)
{
    Serial.println();
    Serial.println("[TELEMETRY] EVENT");

    Serial.print("[TELEMETRY] Type: ");
    Serial.println(getEventName(eventType));

    Serial.print("[TELEMETRY] Pack Voltage: ");
    Serial.print(data.packVoltage, 2);
    Serial.println(" V");

    Serial.print("[TELEMETRY] SOC: ");
    Serial.print(data.soc, 1);
    Serial.println(" %");

    Serial.print("[TELEMETRY] Imbalance: ");
    Serial.print(data.imbalance, 3);
    Serial.println(" V");

    Serial.print("[TELEMETRY] Weakest Cell: ");

    if (data.weakestCell >= 0)
    {
        Serial.println(data.weakestCell + 1);
    }
    else
    {
        Serial.println("N/A");
    }

    Serial.print("[TELEMETRY] Strongest Cell: ");

    if (data.strongestCell >= 0)
    {
        Serial.println(data.strongestCell + 1);
    }
    else
    {
        Serial.println("N/A");
    }

    Serial.print("[TELEMETRY] Relay: ");

    if (data.relayState == RELAY_ON)
    {
        Serial.println("ON");
    }
    else
    {
        Serial.println("OFF");
    }

    Serial.print("[TELEMETRY] State: ");
    Serial.println(data.stateName);

    Serial.print("[TELEMETRY] Fault ID: ");
    Serial.println(data.faultId);

    Serial.print("[TELEMETRY] Imbalance Warning: ");
    Serial.println(
        data.imbalanceWarning ? "YES" : "NO"
    );

    Serial.print("[TELEMETRY] Network: ");

    if (isNetworkAvailable())
    {
        Serial.println("AVAILABLE");
    }
    else
    {
        Serial.println("OFFLINE");
    }

    Serial.print("[TELEMETRY] Queue Depth: ");
    Serial.println(queueCount);
}

// =====================================================
// PROCESS EVENT
// =====================================================

void TelemetryManager::processEvent(
    TelemetryEventType eventType,
    const TelemetryData &data
)
{
    if (isNetworkAvailable())
    {
        sendEvent(eventType, data);
    }
    else
    {
        Serial.print(
            "[TELEMETRY] Network unavailable - queueing "
        );

        Serial.println(getEventName(eventType));

        enqueueEvent(eventType, data);
    }
}

// =====================================================
// MAIN UPDATE
// =====================================================

void TelemetryManager::update(
    const BMSData &bmsData,
    const SafetyData &safetyData,
    FaultState faultState,
    String stateName,
    String faultId,
    float packVoltage,
    const float cellVoltage[]
)
{
    unsigned long currentTime = millis();

    // -------------------------------------------------
    // Network maintenance
    // -------------------------------------------------

    updateNetwork();
    updateRSSI();

    // -------------------------------------------------
    // Build telemetry snapshot
    // -------------------------------------------------

    TelemetryData data;

    data.packVoltage = packVoltage;
    data.soc = bmsData.soc;
    data.imbalance = bmsData.imbalance;

    data.weakestCell = bmsData.weakestCell;
    data.strongestCell = bmsData.strongestCell;

    data.relayState = safetyData.relayState;
    data.faultState = faultState;

    data.faultId = faultId;
    data.stateName = stateName;

    data.imbalanceWarning =
        bmsData.imbalanceWarning;

    // -------------------------------------------------
    // Fault detected
    // -------------------------------------------------

    bool faultActive =
        safetyData.faultDetected;

    if (
        faultActive &&
        !previousFaultActive
    )
    {
        processEvent(
            EVENT_FAULT,
            data
        );
    }

    // -------------------------------------------------
    // Fault cleared
    // -------------------------------------------------

    if (
        !faultActive &&
        previousFaultActive
    )
    {
        processEvent(
            EVENT_FAULT_CLEARED,
            data
        );
    }

    // -------------------------------------------------
    // Relay changed
    // -------------------------------------------------

    if (
        safetyData.relayState !=
        previousRelayState
    )
    {
        processEvent(
            EVENT_RELAY_CHANGE,
            data
        );
    }

    // -------------------------------------------------
    // Fault state changed
    // -------------------------------------------------

    if (
        faultState !=
        previousFaultState
    )
    {
        processEvent(
            EVENT_STATE_CHANGE,
            data
        );
    }

    // -------------------------------------------------
    // Imbalance warning
    // -------------------------------------------------

    if (
        bmsData.imbalanceWarning &&
        !previousImbalanceWarning
    )
    {
        processEvent(
            EVENT_IMBALANCE_WARNING,
            data
        );
    }

    // -------------------------------------------------
    // Periodic telemetry
    // -------------------------------------------------

    if (
        currentTime - lastPeriodicTime >=
        PERIODIC_INTERVAL
    )
    {
        lastPeriodicTime =
            currentTime;

        processEvent(
            EVENT_PERIODIC,
            data
        );
    }

    // -------------------------------------------------
    // FIFO replay
    // -------------------------------------------------
    //
    // In Wokwi there is no Blynk backend.
    // Once Wi-Fi is available, replay one queued
    // event per update cycle to Serial.
    // -------------------------------------------------

    if (
        isNetworkAvailable() &&
        queueCount > 0
    )
    {
        QueuedTelemetryEvent queuedEvent;

        if (
            dequeueEvent(queuedEvent)
        )
        {
            sendQueuedEvent(
                queuedEvent
            );
        }
    }

    // -------------------------------------------------
    // Telemetry status
    // -------------------------------------------------

    Serial.print("[TELEMETRY] Network: ");

    if (isNetworkAvailable())
    {
        Serial.println("ONLINE");
    }
    else
    {
        Serial.println("OFFLINE");
    }

    Serial.print("[TELEMETRY] RSSI: ");
    Serial.print(currentRSSI);
    Serial.println(" dBm");

    Serial.print("[TELEMETRY] Queue depth: ");
    Serial.println(queueCount);

    // -------------------------------------------------
    // Save previous state
    // -------------------------------------------------

    previousRelayState =
        safetyData.relayState;

    previousFaultState =
        faultState;

    previousFaultActive =
        faultActive;

    previousImbalanceWarning =
        bmsData.imbalanceWarning;
}

// =====================================================
// GETTERS
// =====================================================

uint8_t TelemetryManager::getQueueDepth() const
{
    return queueCount;
}

int TelemetryManager::getRSSI() const
{
    return currentRSSI;
}

bool TelemetryManager::isConnected() const
{
    return networkState == NETWORK_CONNECTED;
}