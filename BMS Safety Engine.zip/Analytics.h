#ifndef ANALYTICS_H
#define ANALYTICS_H

#include <Arduino.h>

#include "BMS.h"
#include "Safety.h"
#include "FaultState.h"

/* =========================================================
   ANALYTICS CONFIGURATION
   ========================================================= */

#ifndef ANALYSIS_INTERVAL
#define ANALYSIS_INTERVAL 1000UL
#endif

#ifndef HISTORY_SIZE
#define HISTORY_SIZE 20
#endif

#ifndef FAULT_HISTORY_SIZE
#define FAULT_HISTORY_SIZE 10
#endif

/* =========================================================
   ANALYTICS SEVERITY
   ========================================================= */

enum AnalyticsSeverity
{
    ANALYTICS_NORMAL = 0,
    ANALYTICS_WARNING,
    ANALYTICS_CRITICAL
};

/* =========================================================
   ANALYTICS DATA
   ========================================================= */

struct AnalyticsData
{
    /* Battery information */
    float packVoltage;
    float soc;
    float imbalance;

    float minimumCellVoltage;
    float maximumCellVoltage;

    int weakestCell;
    int strongestCell;

    /* Statistics */
    unsigned long sampleCount;
    unsigned long faultCount;
    unsigned long stateChangeCount;
    unsigned long uptimeSeconds;

    /* Risk */
    float riskScore;

    bool batteryWarning;
    bool criticalCondition;

    AnalyticsSeverity severity;

    /* Trends */
    String voltageTrend;
    String imbalanceTrend;

    /* Health */
    String healthStatus;
    String maintenanceRecommendation;

    /* Current state */
    String currentState;
    String currentFaultId;
};

/* =========================================================
   ANALYTICS MANAGER
   ========================================================= */

class AnalyticsManager
{
public:

    /* Constructor */
    AnalyticsManager();

    /* Initialization */
    void begin();

    /* -----------------------------------------------------
       Main analytics update
       ----------------------------------------------------- */

    void update(
        const BMSData &bmsData,
        const SafetyData &safetyData,
        FaultState faultState,
        String stateName,
        String faultId,
        float packVoltage
    );

    /* -----------------------------------------------------
       Reports
       ----------------------------------------------------- */

    void printReport();

    void printTask6ExecutiveSummary();

    void printTask6HistoricalTrends();

    void printTask6FaultHistory();

    void printTask6Dashboard();

    void printDashboard();

    /* -----------------------------------------------------
       Data access
       ----------------------------------------------------- */

    AnalyticsData getData();

    /* -----------------------------------------------------
       Getters
       ----------------------------------------------------- */

    float getRiskScore();

    unsigned long getFaultCount();

    unsigned long getStateChangeCount();

    unsigned long getUptimeSeconds();

    AnalyticsSeverity getSeverity();

    String getHealthStatus();

    String getMaintenanceRecommendation();

    String getCurrentState();

    String getCurrentFaultId();

    String getVoltageTrend();

    String getImbalanceTrend();

    float getCurrentSOC();

    float getCurrentImbalance();

    float getCurrentPackVoltage();

private:

    /* =====================================================
       CURRENT BATTERY DATA
       ===================================================== */

    float previousPackVoltage;

    float previousImbalance;

    float currentPackVoltage;

    float currentSOC;

    float currentImbalance;

    float currentMinimumCellVoltage;

    float currentMaximumCellVoltage;

    int currentWeakestCell;

    int currentStrongestCell;

    /* =====================================================
       CURRENT ANALYTICS
       ===================================================== */

    String currentVoltageTrend;

    String currentImbalanceTrend;

    String currentHealthStatus;

    String currentStateName;

    String currentFaultId;

    // Added to fix currentRiskScore undeclared compilation error
    float currentRiskScore;

    /* =====================================================
       COUNTERS
       ===================================================== */

    unsigned long sampleCount;

    unsigned long faultCount;

    unsigned long stateChangeCount;

    /* =====================================================
       FAULT TRACKING
       ===================================================== */

    bool previousFaultActive;

    FaultState previousFaultState;

    String lastCountedFaultId;

    String lastRecordedFaultId;

    /* =====================================================
       TIMING
       ===================================================== */

    unsigned long lastAnalysisTime;

    unsigned long systemStartTime;

    /* =====================================================
       HISTORICAL DATA
       ===================================================== */

    float imbalanceHistory[HISTORY_SIZE];

    float voltageHistory[HISTORY_SIZE];

    float socHistory[HISTORY_SIZE];

    float riskHistory[HISTORY_SIZE];

    uint8_t historyIndex;

    uint8_t historyCount;

    /* =====================================================
       FAULT HISTORY
       ===================================================== */

    struct FaultHistory
    {
        unsigned long timestamp;

        String faultId;

        String stateName;

        String severity;
    };

    FaultHistory faultHistory[FAULT_HISTORY_SIZE];

    uint8_t faultHistoryIndex;

    uint8_t faultHistoryCount;

    /* =====================================================
       INTERNAL FUNCTIONS
       ===================================================== */

    void addHistorySample(
        float packVoltage,
        float soc,
        float imbalance,
        float riskScore
    );

    void addFaultHistory(
        const String &faultId,
        const String &stateName,
        AnalyticsSeverity severity
    );

    float calculateAverage(
        const float buffer[],
        uint8_t count
    );

    float calculateRecentAverage(
        const float buffer[],
        uint8_t count
    );

    String calculateVoltageTrend(
        float packVoltage
    );

    String calculateImbalanceTrend(
        float imbalance
    );

    String calculateHealthStatus(
        float imbalance,
        bool faultActive,
        FaultState state
    );

    AnalyticsSeverity calculateSeverity(
        float imbalance,
        bool faultActive,
        FaultState state
    );

    float calculateRiskScore(
        float imbalance,
        bool faultActive,
        FaultState state
    );

    String generateMaintenanceRecommendation(
        float riskScore,
        float imbalance,
        unsigned long faults
    );

    void printAnalyticsReport(
        const String &stateName,
        const String &faultId,
        float riskScore,
        AnalyticsSeverity severity
    );
};

#endif
