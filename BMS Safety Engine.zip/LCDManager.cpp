#include "LCDManager.h"

// =====================================================
// CONSTRUCTOR
// =====================================================

LCDManager::LCDManager()
    : lcd(0x27, 16, 2)
{
    currentPage = 0;

    lastPageChange = 0;

    lastLine1 = "";
    lastLine2 = "";

    criticalFaultShown = false;
}

// =====================================================
// LCD INITIALIZATION
// =====================================================

void LCDManager::begin()
{
    lcd.init();
    lcd.backlight();

    // Startup screen
    lcd.clear();

    lcd.setCursor(0, 0);
    lcd.print("BMS SYSTEM");

    lcd.setCursor(0, 1);
    lcd.print("STARTING...");

    // Startup delay only
    delay(1000);

    // Clear startup screen
    lcd.clear();

    // Reset LCD cache
    lastLine1 = "";
    lastLine2 = "";

    currentPage = 0;

    lastPageChange = millis();

    criticalFaultShown = false;
}

// =====================================================
// UPDATE ONLY CHANGED LINE
// =====================================================

void LCDManager::updateLine(
    int row,
    String text
)
{
    // -------------------------------------------------
    // Limit text to 16 characters
    // -------------------------------------------------

    if (text.length() > 16)
    {
        text = text.substring(0, 16);
    }

    // -------------------------------------------------
    // Fill unused characters with spaces
    // -------------------------------------------------

    while (text.length() < 16)
    {
        text += " ";
    }

    // -------------------------------------------------
    // LINE 1
    // -------------------------------------------------

    if (row == 0)
    {
        // Do not write if nothing changed
        if (text == lastLine1)
        {
            return;
        }

        lcd.setCursor(0, 0);
        lcd.print(text);

        lastLine1 = text;
    }

    // -------------------------------------------------
    // LINE 2
    // -------------------------------------------------

    else
    {
        // Do not write if nothing changed
        if (text == lastLine2)
        {
            return;
        }

        lcd.setCursor(0, 1);
        lcd.print(text);

        lastLine2 = text;
    }
}

// =====================================================
// PAGE 1 - BATTERY STATUS
// =====================================================

void LCDManager::showPage1(
    const BMSData &bmsData
)
{
    String line1 = "BMS STATUS";

    String line2 =
        "SOC:" +
        String(bmsData.soc, 0) +
        "%";

    updateLine(0, line1);
    updateLine(1, line2);
}

// =====================================================
// PAGE 2 - CELL HEALTH
// =====================================================

void LCDManager::showPage2(
    const BMSData &bmsData
)
{
    String line1 =
        "W:" +
        String(bmsData.weakestCell + 1) +
        " S:" +
        String(bmsData.strongestCell + 1);

    String line2 =
        "IMB:" +
        String(bmsData.imbalance, 2) +
        "V";

    updateLine(0, line1);
    updateLine(1, line2);
}

// =====================================================
// PAGE 3 - SAFETY / TELEMETRY
// =====================================================

void LCDManager::showPage3(
    const SafetyData &safetyData
)
{
    String relayText;

    // -------------------------------------------------
    // Relay status
    // -------------------------------------------------

    if (safetyData.relayState == RELAY_ON)
    {
        relayText = "ON";
    }
    else if (safetyData.relayState == RELAY_FAULT)
    {
        relayText = "FAULT";
    }
    else
    {
        relayText = "OFF";
    }

    String line1 =
        "RELAY:" +
        relayText;

    // -------------------------------------------------
    // Safety state / fault
    // -------------------------------------------------

    String line2;

    if (safetyData.faultId == "NONE")
    {
        line2 = "STATE: NORMAL";
    }
    else
    {
        line2 = safetyData.faultId;
    }

    updateLine(0, line1);
    updateLine(1, line2);
}

// =====================================================
// CRITICAL FAULT DISPLAY
// =====================================================

void LCDManager::showCriticalFault(
    const String &faultId,
    const String &stateName
)
{
    String line1;
    String line2;

    // -------------------------------------------------
    // FAILSAFE
    // -------------------------------------------------

    if (stateName == "FAILSAFE")
    {
        line1 = "!! FAILSAFE !!";
    }

    // -------------------------------------------------
    // SHUTDOWN
    // -------------------------------------------------

    else if (stateName == "SHUTDOWN")
    {
        line1 = "!! SHUTDOWN !!";
    }

    // -------------------------------------------------
    // Other critical state
    // -------------------------------------------------

    else
    {
        line1 = "!! CRITICAL !!";
    }

    // Fault ID
    line2 = faultId;

    // Update only if changed
    updateLine(0, line1);
    updateLine(1, line2);

    criticalFaultShown = true;
}

// =====================================================
// MAIN LCD UPDATE
// =====================================================

void LCDManager::update(
    const BMSData &bmsData,
    const SafetyData &safetyData,
    const String &stateName,
    const String &faultId
)
{
    unsigned long currentTime = millis();

    // =================================================
    // CRITICAL STATE OVERRIDE
    // =================================================
    //
    // FAILSAFE and SHUTDOWN immediately override
    // the normal rotating pages.
    //
    // =================================================

    if (
        stateName == "FAILSAFE" ||
        stateName == "SHUTDOWN"
    )
    {
        showCriticalFault(
            faultId,
            stateName
        );

        return;
    }

    // =================================================
    // RECOVERY FROM CRITICAL STATE
    // =================================================
    //
    // Do NOT use lcd.clear() here.
    //
    // Reset the cached lines and allow the next
    // normal page to overwrite the display.
    //
    // This avoids visible flicker.
    //
    // =================================================

    if (criticalFaultShown)
    {
        clearCriticalFault();
    }

    // =================================================
    // NON-BLOCKING PAGE ROTATION
    // =================================================

    if (
        currentTime - lastPageChange >=
        PAGE_INTERVAL
    )
    {
        lastPageChange = currentTime;

        currentPage++;

        if (currentPage > 2)
        {
            currentPage = 0;
        }
    }

    // =================================================
    // DISPLAY CURRENT PAGE
    // =================================================

    if (currentPage == 0)
    {
        showPage1(bmsData);
    }
    else if (currentPage == 1)
    {
        showPage2(bmsData);
    }
    else
    {
        showPage3(safetyData);
    }
}

// =====================================================
// CLEAR CRITICAL FAULT
// =====================================================

void LCDManager::clearCriticalFault()
{
    criticalFaultShown = false;

    // -------------------------------------------------
    // IMPORTANT:
    // Do NOT call lcd.clear()
    // -------------------------------------------------

    lastLine1 = "";
    lastLine2 = "";

    // Restart normal page rotation
    currentPage = 0;

    lastPageChange = millis();
}