#include "BMS.h"

// --------------------------------------------------
// Battery Analysis
// --------------------------------------------------

BMSData analyzeBattery(
    float cellVoltage[],
    float soc,
    float dischargeRate
) {
    BMSData result;

    // --------------------------------------------------
    // Initialize weakest and strongest cells
    // --------------------------------------------------

    result.weakestCell = 0;
    result.strongestCell = 0;

    // --------------------------------------------------
    // Find weakest and strongest cells
    //
    // Uses NUM_CELLS so the algorithm automatically
    // scales from 1 cell to 4, 8, 16, etc.
    // --------------------------------------------------

    for (int i = 1; i < NUM_CELLS; i++) {

        if (cellVoltage[i] <
            cellVoltage[result.weakestCell]) {

            result.weakestCell = i;
        }

        if (cellVoltage[i] >
            cellVoltage[result.strongestCell]) {

            result.strongestCell = i;
        }
    }

    // --------------------------------------------------
    // Calculate voltage imbalance
    // --------------------------------------------------

    result.imbalance =
        cellVoltage[result.strongestCell] -
        cellVoltage[result.weakestCell];

    // --------------------------------------------------
    // Store battery operating information
    // --------------------------------------------------

    result.soc = constrain(soc, 0.0f, 100.0f);
    result.dischargeRate = dischargeRate;

    // --------------------------------------------------
    // Adaptive imbalance threshold
    //
    // Base threshold:
    //     0.10 V
    //
    // Low SoC:
    //     Allow slightly more imbalance
    //
    // High SoC:
    //     Use a tighter threshold
    //
    // High discharge:
    //     Allow additional temporary imbalance
    // --------------------------------------------------

    float threshold = 0.10f;

    // Low state of charge
    if (result.soc < 30.0f) {

        threshold += 0.03f;
    }

    // High state of charge
    else if (result.soc > 80.0f) {

        threshold -= 0.02f;
    }

    // Higher discharge rate can temporarily increase
    // the voltage difference between cells.
    if (dischargeRate > 2.0f) {

        threshold += 0.05f;
    }

    // Keep threshold within a safe operating range.
    result.adaptiveThreshold =
        constrain(threshold, 0.05f, 0.20f);

    // --------------------------------------------------
    // Imbalance warning
    // --------------------------------------------------

    result.imbalanceWarning =
        result.imbalance > result.adaptiveThreshold;

    // --------------------------------------------------
    // Imbalance trend detection
    //
    // A small deadband prevents the trend from rapidly
    // changing because of ADC measurement noise.
    // --------------------------------------------------

    static float previousImbalance = 0.0f;
    static bool firstReading = true;

    const float TREND_DEADBAND = 0.005f;

    if (firstReading) {

        result.trend = "STABLE";

        firstReading = false;
    }
    else {

        float difference =
            result.imbalance - previousImbalance;

        if (difference > TREND_DEADBAND) {

            result.trend = "INCREASING";
        }
        else if (difference < -TREND_DEADBAND) {

            result.trend = "DECREASING";
        }
        else {

            result.trend = "STABLE";
        }
    }

    // Save current imbalance for the next analysis cycle.
    previousImbalance = result.imbalance;

    return result;
}