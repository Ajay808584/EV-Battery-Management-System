#ifndef TELEMETRY_H
#define TELEMETRY_H

#include <Arduino.h>
#include <WiFi.h>

#include "BMS.h"
#include "Safety.h"
#include "FaultState.h"

// =====================================================
// TELEMETRY EVENT TYPES
// =====================================================

enum TelemetryEventType
{
    EVENT_PERIODIC,
    EVENT_FAULT,
    EVENT_FAULT_CLEARED,
    EVENT_RELAY_CHANGE,
    EVENT_STATE_CHANGE,
    EVENT_IMBALANCE_WARNING
};

// =====================================================
// NETWORK STATES
// =====================================================

enum TelemetryNetworkState
{
    NETWORK_DISCONNECTED,
    NETWORK_CONNECTING,
    NETWORK_CONNECTED
};

// =====================================================
// TELEMETRY DATA
// =====================================================

struct TelemetryData
{
    float packVoltage;
    float soc;
    float imbalance;

    int weakestCell;
    int strongestCell;

    RelayState relayState;
    FaultState faultState;

    String faultId;
    String stateName;

    bool imbalanceWarning;
};

// =====================================================
// QUEUED EVENT
// =====================================================

struct QueuedTelemetryEvent
{
    TelemetryEventType eventType;

    unsigned long timestamp;

    float packVoltage;
    float soc;
    float imbalance;

    int weakestCell;
    int strongestCell;

    RelayState relayState;
    FaultState faultState;

    bool imbalanceWarning;

    char faultId[32];
    char stateName[24];
};

// =====================================================
// TELEMETRY MANAGER
// =====================================================

class TelemetryManager
{
private:

    // -------------------------------------------------
    // Periodic telemetry
    // -------------------------------------------------

    unsigned long lastPeriodicTime;

    const unsigned long PERIODIC_INTERVAL = 5000;

    // -------------------------------------------------
    // Previous states
    // -------------------------------------------------

    RelayState previousRelayState;
    FaultState previousFaultState;

    bool previousFaultActive;
    bool previousImbalanceWarning;

    // -------------------------------------------------
    // Network state
    // -------------------------------------------------

    TelemetryNetworkState networkState;

    unsigned long networkStateStart;
    unsigned long lastWiFiAttempt;
    unsigned long lastRSSIUpdate;

    int currentRSSI;

    const unsigned long WIFI_RETRY_INTERVAL = 5000;
    const unsigned long RSSI_INTERVAL = 5000;

    // -------------------------------------------------
    // Fixed-size FIFO
    // -------------------------------------------------

    static const uint8_t QUEUE_SIZE = 16;

    QueuedTelemetryEvent eventQueue[QUEUE_SIZE];

    uint8_t queueHead;
    uint8_t queueTail;
    uint8_t queueCount;

    // -------------------------------------------------
    // Queue management
    // -------------------------------------------------

    bool enqueueEvent(
        TelemetryEventType eventType,
        const TelemetryData &data
    );

    bool dequeueEvent(
        QueuedTelemetryEvent &event
    );

    void sendQueuedEvent(
        const QueuedTelemetryEvent &event
    );

    // -------------------------------------------------
    // Event handling
    // -------------------------------------------------

    void processEvent(
        TelemetryEventType eventType,
        const TelemetryData &data
    );

    void sendEvent(
        TelemetryEventType eventType,
        const TelemetryData &data
    );

    // -------------------------------------------------
    // Network
    // -------------------------------------------------

    void updateNetwork();

    void updateRSSI();

    bool isNetworkAvailable();

    // -------------------------------------------------
    // Serial output
    // -------------------------------------------------

    const char *getEventName(
        TelemetryEventType eventType
    );

    void printTelemetryData(
        const TelemetryData &data
    );

public:

    TelemetryManager();

    void begin();

    void update(
        const BMSData &bmsData,
        const SafetyData &safetyData,
        FaultState faultState,
        String stateName,
        String faultId,
        float packVoltage,
        const float cellVoltage[]
    );

    uint8_t getQueueDepth() const;

    int getRSSI() const;

    bool isConnected() const;
};

#endif