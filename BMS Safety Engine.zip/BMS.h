#ifndef BMS_H
#define BMS_H

#include <Arduino.h>

#define NUM_CELLS 4

struct BMSData {
    int weakestCell;
    int strongestCell;

    float imbalance;
    float soc;
    float dischargeRate;
    float adaptiveThreshold;

    bool imbalanceWarning;

    String trend;
};

BMSData analyzeBattery(
    float cellVoltage[],
    float soc,
    float dischargeRate
);

#endif