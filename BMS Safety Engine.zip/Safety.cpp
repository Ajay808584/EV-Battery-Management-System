#include "Safety.h"
#include <math.h>

// ============================================================
// CONSTRUCTOR
// ============================================================

SafetyManager::SafetyManager()
{
    currentState = RELAY_ON;

    previousVoltage = 0.0f;
    windowIndex = 0;
    sampleCount = 0;

    lastChangeTime = 0;
    recoveryStartTime = 0;
    jumpSuppressionUntil = 0;

    firstReading = true;
    recoveryActive = false;
    sensorActivitySeen = false;

    pendingFault = "NONE";
    activeFaultId = "NONE";
    faultCount = 0;

    for (int i = 0; i < 5; i++)
        voltageWindow[i] = 0.0f;
}

// ============================================================
// INITIALIZATION
// ============================================================

void SafetyManager::begin()
{
    Serial.println();
    Serial.println("================================");
    Serial.println("      SAFETY SYSTEM STARTED");
    Serial.println("================================");

    currentState = RELAY_ON;

    previousVoltage = 0.0f;
    windowIndex = 0;
    sampleCount = 0;

    lastChangeTime = millis();
    recoveryStartTime = 0;
    jumpSuppressionUntil = 0;

    firstReading = true;
    recoveryActive = false;
    sensorActivitySeen = false;

    pendingFault = "NONE";
    activeFaultId = "NONE";
    faultCount = 0;

    for (int i = 0; i < 5; i++)
        voltageWindow[i] = 0.0f;
}

// ============================================================
// VALIDATE ALL CELLS AND DETECT CELL VOLTAGE FAULTS
// Returns true when sensor data is invalid.
// ============================================================

bool SafetyManager::cellsHaveTripFault(
    const float cellVoltages[],
    int cellCount,
    bool &cellOverVoltage,
    bool &cellUnderVoltage
) const
{
    cellOverVoltage = false;
    cellUnderVoltage = false;

    if (cellVoltages == nullptr || cellCount <= 0)
        return true;

    for (int i = 0; i < cellCount; i++)
    {
        float voltage = cellVoltages[i];

        if (!isfinite(voltage) || voltage <= 0.0f)
            return true;

        if (voltage > CELL_OV_TRIP)
            cellOverVoltage = true;

        if (voltage < CELL_UV_TRIP)
            cellUnderVoltage = true;
    }

    return false;
}

// ============================================================
// CHECK WHETHER ALL CELLS ARE SAFE FOR RECOVERY
// ============================================================

bool SafetyManager::cellsSafeForRecovery(
    const float cellVoltages[],
    int cellCount
) const
{
    if (cellVoltages == nullptr || cellCount <= 0)
        return false;

    float minCell = 1000.0f;
    float maxCell = 0.0f;

    for (int i = 0; i < cellCount; i++)
    {
        float voltage = cellVoltages[i];

        if (!isfinite(voltage))
            return false;

        if (voltage < CELL_UV_CLEAR ||
            voltage > CELL_OV_CLEAR)
        {
            return false;
        }

        if (voltage < minCell)
            minCell = voltage;

        if (voltage > maxCell)
            maxCell = voltage;
    }

    return (maxCell - minCell) <= MAX_RECOVERY_IMBALANCE;
}

// ============================================================
// MAIN SAFETY UPDATE
// ============================================================

SafetyData SafetyManager::update(
    float batteryVoltage,
    const float cellVoltages[],
    int cellCount
)
{
    SafetyData result;

    result.relayState = currentState;
    result.overVoltage = false;
    result.underVoltage = false;
    result.frozenReading = false;
    result.unrealisticJump = false;
    result.noisySignal = false;
    result.sensorInvalid = false;
    result.faultDetected = false;
    result.faultId = "NONE";

    const unsigned long now = millis();

    const bool packValid =
        isfinite(batteryVoltage) && batteryVoltage > 0.0f;

    bool cellOverVoltage = false;
    bool cellUnderVoltage = false;

    const bool invalidCells = cellsHaveTripFault(
        cellVoltages,
        cellCount,
        cellOverVoltage,
        cellUnderVoltage
    );

    // --------------------------------------------------------
    // FIRST READING
    // --------------------------------------------------------

    if (firstReading)
    {
        previousVoltage = batteryVoltage;
        lastChangeTime = now;
        firstReading = false;
    }

    const float voltageChange =
        batteryVoltage - previousVoltage;

    // --------------------------------------------------------
    // STORE VOLTAGE SAMPLE
    // --------------------------------------------------------

    voltageWindow[windowIndex] = batteryVoltage;
    windowIndex = (windowIndex + 1) % 5;

    if (sampleCount < 5)
        sampleCount++;

    // --------------------------------------------------------
    // SENSOR VALIDATION
    // --------------------------------------------------------

    String detectedFault = "NONE";

    if (!packValid || invalidCells)
    {
        result.sensorInvalid = true;
        detectedFault = "SENSOR_INVALID";
    }

    // --------------------------------------------------------
    // PACK AND INDIVIDUAL-CELL PROTECTION
    // OV and UV have priority over jump detection.
    // --------------------------------------------------------

    if (packValid)
    {
        if (batteryVoltage > OVER_VOLTAGE_TRIP ||
            cellOverVoltage)
        {
            result.overVoltage = true;
            detectedFault = "OVER_VOLTAGE";
        }
        else if (batteryVoltage < UNDER_VOLTAGE_TRIP ||
                 cellUnderVoltage)
        {
            result.underVoltage = true;
            detectedFault = "UNDER_VOLTAGE";
        }
    }

    // --------------------------------------------------------
    // TRACK SENSOR ACTIVITY
    // --------------------------------------------------------

    if (isfinite(voltageChange) &&
        fabsf(voltageChange) > 0.01f)
    {
        lastChangeTime = now;

        if (currentState == RELAY_FAULT &&
            activeFaultId == "FROZEN_READING")
        {
            sensorActivitySeen = true;
        }
    }

    // --------------------------------------------------------
    // FROZEN READING DETECTION
    // --------------------------------------------------------

    if (now - lastChangeTime > FROZEN_TIME)
    {
        result.frozenReading = true;

        if (detectedFault == "NONE")
            detectedFault = "FROZEN_READING";
    }

    // --------------------------------------------------------
    // RECOVERY RANGE CHECKS
    // --------------------------------------------------------

    const bool packSafeForRecovery =
        packValid &&
        batteryVoltage >= UNDER_VOLTAGE_CLEAR &&
        batteryVoltage <= OVER_VOLTAGE_CLEAR;

    const bool cellsSafeForRecoveryNow =
        cellsSafeForRecovery(cellVoltages, cellCount);

    const bool safeRecoveryCandidate =
        packSafeForRecovery && cellsSafeForRecoveryNow;

    const bool suppressJump =
        now < jumpSuppressionUntil;

    // --------------------------------------------------------
    // UNREALISTIC JUMP DETECTION
    // Never replace an already detected OV or UV fault.
    // --------------------------------------------------------

    if (packValid &&
        fabsf(voltageChange) > 1.0f &&
        !suppressJump &&
        !safeRecoveryCandidate)
    {
        result.unrealisticJump = true;

        if (detectedFault == "NONE" &&
            !result.overVoltage &&
            !result.underVoltage)
        {
            detectedFault = "UNREALISTIC_JUMP";
        }
    }

    // --------------------------------------------------------
    // MOVING-WINDOW NOISE ESTIMATE
    // --------------------------------------------------------

    if (sampleCount >= 5)
    {
        float sum = 0.0f;

        for (int i = 0; i < sampleCount; i++)
            sum += voltageWindow[i];

        const float mean = sum / sampleCount;

        float variance = 0.0f;

        for (int i = 0; i < sampleCount; i++)
        {
            const float difference =
                voltageWindow[i] - mean;

            variance += difference * difference;
        }

        variance /= sampleCount;

        const float standardDeviation = sqrtf(variance);

        int directionChanges = 0;

        for (int i = 2; i < sampleCount; i++)
        {
            const float change1 =
                voltageWindow[i - 1] - voltageWindow[i - 2];

            const float change2 =
                voltageWindow[i] - voltageWindow[i - 1];

            if ((change1 > 0.05f && change2 < -0.05f) ||
                (change1 < -0.05f && change2 > 0.05f))
            {
                directionChanges++;
            }
        }

        if (standardDeviation > 0.50f &&
            directionChanges >= 2)
        {
            result.noisySignal = true;
        }
    }

    // --------------------------------------------------------
    // FAULT DEBOUNCING
    // Critical faults trip immediately.
    // --------------------------------------------------------

    const bool immediateFault =
        detectedFault == "OVER_VOLTAGE" ||
        detectedFault == "UNDER_VOLTAGE" ||
        detectedFault == "SENSOR_INVALID" ||
        detectedFault == "UNREALISTIC_JUMP";

    if (detectedFault != "NONE")
    {
        if (immediateFault)
        {
            result.faultDetected = true;
            result.faultId = detectedFault;

            pendingFault = detectedFault;
            faultCount = FAULT_DEBOUNCE_COUNT;
        }
        else
        {
            if (pendingFault == detectedFault)
            {
                faultCount++;
            }
            else
            {
                pendingFault = detectedFault;
                faultCount = 1;
            }

            if (faultCount >= FAULT_DEBOUNCE_COUNT)
            {
                result.faultDetected = true;
                result.faultId = detectedFault;
            }
        }
    }
    else
    {
        pendingFault = "NONE";
        faultCount = 0;
    }

    // --------------------------------------------------------
    // LATCH FIRST FAULT AND TRIP THE RELAY
    // --------------------------------------------------------

    if (result.faultDetected)
    {
        recoveryActive = false;
        recoveryStartTime = 0;

        if (currentState != RELAY_FAULT)
        {
            activeFaultId = result.faultId;
            sensorActivitySeen = false;
            currentState = RELAY_FAULT;

            Serial.println();
            Serial.println("[SAFETY] Relay -> FAULT");
            Serial.print("[SAFETY] Fault ID: ");
            Serial.println(activeFaultId);
            Serial.println("[SAFETY] Protection activated");
        }
    }

    // --------------------------------------------------------
    // VERIFIED RECOVERY
    // --------------------------------------------------------

    if (currentState == RELAY_FAULT &&
        !result.faultDetected)
    {
        const bool cellsSafe =
            cellsSafeForRecovery(cellVoltages, cellCount);

        const bool packSafe =
            packValid &&
            batteryVoltage >= UNDER_VOLTAGE_CLEAR &&
            batteryVoltage <= OVER_VOLTAGE_CLEAR;

        bool faultCleared = false;

        if (activeFaultId == "OVER_VOLTAGE" ||
            activeFaultId == "UNDER_VOLTAGE" ||
            activeFaultId == "SENSOR_INVALID")
        {
            faultCleared = packSafe && cellsSafe;
        }
        else if (activeFaultId == "UNREALISTIC_JUMP")
        {
            faultCleared =
                packSafe &&
                cellsSafe &&
                fabsf(voltageChange) <= 1.0f;
        }
        else if (activeFaultId == "FROZEN_READING")
        {
            faultCleared =
                packSafe &&
                cellsSafe &&
                sensorActivitySeen;
        }

        if (!faultCleared)
        {
            recoveryActive = false;
            recoveryStartTime = 0;
        }
        else if (!recoveryActive)
        {
            recoveryActive = true;
            recoveryStartTime = now;

            Serial.println();
            Serial.println(
                "[SAFETY] Fault cleared; readings are in recovery range"
            );
            Serial.println(
                "[SAFETY] Recovery verification started"
            );
        }
        else if (now - recoveryStartTime >= RECOVERY_TIME)
        {
            // Recheck all conditions before enabling the relay.
            const bool finalPackSafe =
                packValid &&
                batteryVoltage >= UNDER_VOLTAGE_CLEAR &&
                batteryVoltage <= OVER_VOLTAGE_CLEAR;

            const bool finalCellsSafe =
                cellsSafeForRecovery(cellVoltages, cellCount);

            if (finalPackSafe && finalCellsSafe)
            {
                Serial.println("[SAFETY] Recovery verified");
                Serial.println("[SAFETY] Relay -> ON");

                currentState = RELAY_ON;

                recoveryActive = false;
                recoveryStartTime = 0;
                activeFaultId = "NONE";
                sensorActivitySeen = false;

                jumpSuppressionUntil =
                    now + JUMP_SUPPRESSION_TIME;

                pendingFault = "NONE";
                faultCount = 0;
                lastChangeTime = now;
            }
            else
            {
                recoveryActive = false;
                recoveryStartTime = 0;
            }
        }
    }

    // --------------------------------------------------------
    // KEEP THE ACTIVE FAULT ID CONSISTENT ACROSS MODULES
    // --------------------------------------------------------

    if (currentState == RELAY_FAULT &&
        activeFaultId != "NONE")
    {
        result.faultId = activeFaultId;
    }
    else if (!result.faultDetected)
    {
        result.faultId = "NONE";
    }

    previousVoltage = batteryVoltage;
    result.relayState = currentState;

    return result;
}

// ============================================================
// GET RELAY STATE
// ============================================================

RelayState SafetyManager::getRelayState()
{
    return currentState;
}

// ============================================================
// CHECK ACTIVE FAULT
// ============================================================

bool SafetyManager::isFaultActive()
{
    return currentState == RELAY_FAULT;
}
