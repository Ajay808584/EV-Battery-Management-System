
#include "Analytics.h"
#include <math.h>

/* =========================================================
   CONSTRUCTOR
   ========================================================= */

AnalyticsManager::AnalyticsManager()
{
    previousPackVoltage = 0.0;
    previousImbalance = 0.0;

    currentPackVoltage = 0.0;
    currentSOC = 0.0;
    currentImbalance = 0.0;
    currentMinimumCellVoltage = 0.0;
    currentMaximumCellVoltage = 0.0;
    currentRiskScore = 0.0;

    currentWeakestCell = -1;
    currentStrongestCell = -1;

    currentVoltageTrend = "STABLE";
    currentImbalanceTrend = "STABLE";
    currentHealthStatus = "NORMAL";

    currentStateName = "NORMAL";
    currentFaultId = "NONE";

    sampleCount = 0;
    faultCount = 0;
    stateChangeCount = 0;

    previousFaultActive = false;
    previousFaultState = static_cast<FaultState>(0);

    lastCountedFaultId = "NONE";
    lastRecordedFaultId = "NONE";

    lastAnalysisTime = 0;
    systemStartTime = 0;

    historyIndex = 0;
    historyCount = 0;

    faultHistoryIndex = 0;
    faultHistoryCount = 0;

    for (int i = 0; i < HISTORY_SIZE; i++)
    {
        imbalanceHistory[i] = 0.0;
        voltageHistory[i] = 0.0;
        socHistory[i] = 0.0;
        riskHistory[i] = 0.0;
    }

    for (int i = 0; i < FAULT_HISTORY_SIZE; i++)
    {
        faultHistory[i].timestamp = 0;
        faultHistory[i].faultId = "NONE";
        faultHistory[i].stateName = "NORMAL";
        faultHistory[i].severity = "NORMAL";
    }
}


/* =========================================================
   BEGIN
   ========================================================= */

void AnalyticsManager::begin()
{
    systemStartTime = millis();
    lastAnalysisTime = 0;

    Serial.println();
    Serial.println("========================================");
    Serial.println("      ANALYTICS ENGINE STARTED");
    Serial.println("========================================");
    Serial.println("[ANALYTICS] Historical monitoring active");
    Serial.println("[ANALYTICS] Risk analysis active");
    Serial.println("[ANALYTICS] Fault history active");
    Serial.println("[ANALYTICS] Maintenance recommendations active");
    Serial.println();
}


/* =========================================================
   MAIN UPDATE
   ========================================================= */

void AnalyticsManager::update(
    const BMSData &bmsData,
    const SafetyData &safetyData,
    FaultState faultState,
    String stateName,
    String faultId,
    float packVoltage
)
{
    unsigned long currentTime = millis();

    if (currentTime - lastAnalysisTime < ANALYSIS_INTERVAL)
    {
        return;
    }

    lastAnalysisTime = currentTime;

    /* Current values */

    currentPackVoltage = packVoltage;
    currentSOC = bmsData.soc;
    currentImbalance = bmsData.imbalance;

    // Convert zero-based cell indexes to human-readable numbers.
    currentWeakestCell = bmsData.weakestCell + 1;
    currentStrongestCell = bmsData.strongestCell + 1;

    currentStateName = stateName;
    currentFaultId = faultId;

    bool faultActive =
        safetyData.faultDetected ||
        (faultId != "NONE" && faultId.length() > 0);

    /* Trends */

    currentVoltageTrend =
        calculateVoltageTrend(currentPackVoltage);

    currentImbalanceTrend =
        calculateImbalanceTrend(currentImbalance);

    /* Severity */

    AnalyticsSeverity severity =
        calculateSeverity(
            currentImbalance,
            faultActive,
            faultState
        );

    /* Health */

    currentHealthStatus =
        calculateHealthStatus(
            currentImbalance,
            faultActive,
            faultState
        );

    /* Risk */

    currentRiskScore =
        calculateRiskScore(
            currentImbalance,
            faultActive,
            faultState
        );

    float riskScore = currentRiskScore;

    /* Sample counter */

    sampleCount++;

    /* State-change counter */

    if (sampleCount > 1 &&
        faultState != previousFaultState)
    {
        stateChangeCount++;
    }

    previousFaultState = faultState;

    /* Count each fault ID once until the fault clears. */

    bool newFaultEvent =
        faultActive &&
        faultId != "NONE" &&
        faultId.length() > 0 &&
        faultId != lastCountedFaultId;

    if (newFaultEvent)
    {
        faultCount++;
        lastCountedFaultId = faultId;
    }

    /* Reset fault tracking after recovery. */

    if (!faultActive &&
        (faultId == "NONE" || faultId.length() == 0))
    {
        lastCountedFaultId = "NONE";
        lastRecordedFaultId = "NONE";
    }

    /* Record each new fault ID once until recovery. */

    if (faultActive &&
        faultId != "NONE" &&
        faultId.length() > 0 &&
        faultId != lastRecordedFaultId)
    {
        addFaultHistory(
            faultId,
            stateName,
            severity
        );

        lastRecordedFaultId = faultId;
    }

    /* Historical data */

    addHistorySample(
        currentPackVoltage,
        currentSOC,
        currentImbalance,
        riskScore
    );

    /* Report */

    printAnalyticsReport(
        stateName,
        faultId,
        riskScore,
        severity
    );
}


/* =========================================================
   ADD HISTORY
   ========================================================= */

void AnalyticsManager::addHistorySample(
    float packVoltage,
    float soc,
    float imbalance,
    float riskScore
)
{
    imbalanceHistory[historyIndex] = imbalance;
    voltageHistory[historyIndex] = packVoltage;
    socHistory[historyIndex] = soc;
    riskHistory[historyIndex] = riskScore;

    historyIndex++;

    if (historyIndex >= HISTORY_SIZE)
    {
        historyIndex = 0;
    }

    if (historyCount < HISTORY_SIZE)
    {
        historyCount++;
    }
}


/* =========================================================
   ADD FAULT HISTORY
   ========================================================= */

void AnalyticsManager::addFaultHistory(
    const String &faultId,
    const String &stateName,
    AnalyticsSeverity severity
)
{
    if (faultId.length() == 0 || faultId == "NONE")
    {
        return;
    }

    faultHistory[faultHistoryIndex].timestamp =
        (millis() - systemStartTime) / 1000;

    faultHistory[faultHistoryIndex].faultId = faultId;
    faultHistory[faultHistoryIndex].stateName = stateName;

    if (severity == ANALYTICS_CRITICAL)
    {
        faultHistory[faultHistoryIndex].severity = "CRITICAL";
    }
    else if (severity == ANALYTICS_WARNING)
    {
        faultHistory[faultHistoryIndex].severity = "WARNING";
    }
    else
    {
        faultHistory[faultHistoryIndex].severity = "NORMAL";
    }

    faultHistoryIndex++;

    if (faultHistoryIndex >= FAULT_HISTORY_SIZE)
    {
        faultHistoryIndex = 0;
    }

    if (faultHistoryCount < FAULT_HISTORY_SIZE)
    {
        faultHistoryCount++;
    }
}


/* =========================================================
   AVERAGE
   ========================================================= */

float AnalyticsManager::calculateAverage(
    const float buffer[],
    uint8_t count
)
{
    if (count == 0)
    {
        return 0.0;
    }

    float total = 0.0;

    for (uint8_t i = 0; i < count; i++)
    {
        total += buffer[i];
    }

    return total / count;
}


/* =========================================================
   RECENT AVERAGE
   ========================================================= */

float AnalyticsManager::calculateRecentAverage(
    const float buffer[],
    uint8_t count
)
{
    if (count == 0)
    {
        return 0.0;
    }

    uint8_t samples = count < 5 ? count : 5;
    float total = 0.0;

    for (uint8_t i = 0; i < samples; i++)
    {
        int index = historyIndex - 1 - i;

        if (index < 0)
        {
            index += HISTORY_SIZE;
        }

        total += buffer[index];
    }

    return total / samples;
}


/* =========================================================
   VOLTAGE TREND
   ========================================================= */

String AnalyticsManager::calculateVoltageTrend(float packVoltage)
{
    if (sampleCount == 0)
    {
        previousPackVoltage = packVoltage;
        return "STABLE";
    }

    float difference = packVoltage - previousPackVoltage;
    previousPackVoltage = packVoltage;

    if (difference > 0.20)
    {
        return "INCREASING";
    }

    if (difference < -0.20)
    {
        return "DECREASING";
    }

    return "STABLE";
}


/* =========================================================
   IMBALANCE TREND
   ========================================================= */

String AnalyticsManager::calculateImbalanceTrend(float imbalance)
{
    if (sampleCount == 0)
    {
        previousImbalance = imbalance;
        return "STABLE";
    }

    float difference = imbalance - previousImbalance;
    previousImbalance = imbalance;

    if (difference > 0.05)
    {
        return "INCREASING";
    }

    if (difference < -0.05)
    {
        return "DECREASING";
    }

    return "STABLE";
}


/* =========================================================
   HEALTH STATUS
   ========================================================= */

String AnalyticsManager::calculateHealthStatus(
    float imbalance,
    bool faultActive,
    FaultState state
)
{
    if (currentStateName == "SHUTDOWN" ||
        currentStateName == "FAILSAFE")
    {
        return "CRITICAL";
    }

    if (currentStateName == "DEGRADED" || faultActive)
    {
        return "WARNING";
    }

    if (imbalance >= 0.50)
    {
        return "CRITICAL";
    }

    if (imbalance >= 0.20)
    {
        return "WARNING";
    }

    return "NORMAL";
}


/* =========================================================
   SEVERITY
   ========================================================= */

AnalyticsSeverity AnalyticsManager::calculateSeverity(
    float imbalance,
    bool faultActive,
    FaultState state
)
{
    if (currentStateName == "SHUTDOWN" ||
        currentStateName == "FAILSAFE")
    {
        return ANALYTICS_CRITICAL;
    }

    if (currentStateName == "DEGRADED" || faultActive)
    {
        return ANALYTICS_WARNING;
    }

    if (imbalance >= 0.50)
    {
        return ANALYTICS_CRITICAL;
    }

    if (imbalance >= 0.20)
    {
        return ANALYTICS_WARNING;
    }

    return ANALYTICS_NORMAL;
}


/* =========================================================
   RISK SCORE
   ========================================================= */

float AnalyticsManager::calculateRiskScore(
    float imbalance,
    bool faultActive,
    FaultState state
)
{
    // A protection state must never appear low-risk.
    if (currentStateName == "SHUTDOWN")
    {
        return 100.0;
    }

    if (currentStateName == "FAILSAFE")
    {
        return 90.0;
    }

    float risk = 0.0;

    /* Imbalance contribution */

    if (imbalance >= 2.0)
    {
        risk += 55.0;
    }
    else if (imbalance >= 1.0)
    {
        risk += 45.0;
    }
    else if (imbalance >= 0.50)
    {
        risk += 30.0;
    }
    else if (imbalance >= 0.20)
    {
        risk += 20.0;
    }

    /* Fault contribution */

    if (faultActive)
    {
        risk += 30.0;
    }

    /* Degraded-state contribution */

    if (currentStateName == "DEGRADED")
    {
        risk += 15.0;
    }

    /* Clamp score to 0–100 */

    if (risk > 100.0)
    {
        risk = 100.0;
    }

    if (risk < 0.0)
    {
        risk = 0.0;
    }

    return risk;
}


/* =========================================================
   MAINTENANCE RECOMMENDATION
   ========================================================= */

String AnalyticsManager::generateMaintenanceRecommendation(
    float riskScore,
    float imbalance,
    unsigned long faults
)
{
    if (riskScore >= 80.0)
    {
        return "Immediate inspection required";
    }

    if (riskScore >= 50.0)
    {
        return "Inspect battery and protection system";
    }

    if (imbalance >= 0.20)
    {
        return "Check cell balancing";
    }

    if (faults > 0)
    {
        return "Monitor recurring faults";
    }

    return "No immediate maintenance required";
}


/* =========================================================
   ANALYTICS REPORT
   ========================================================= */

void AnalyticsManager::printAnalyticsReport(
    const String &stateName,
    const String &faultId,
    float riskScore,
    AnalyticsSeverity severity
)
{
    currentStateName = stateName;
    currentFaultId = faultId;

    currentHealthStatus =
        calculateHealthStatus(
            currentImbalance,
            faultId != "NONE" && faultId.length() > 0,
            previousFaultState
        );

    String recommendation =
        generateMaintenanceRecommendation(
            riskScore,
            currentImbalance,
            faultCount
        );

    Serial.println();
    Serial.println("----------------------------------------");
    Serial.println("          ANALYTICS REPORT");
    Serial.println("----------------------------------------");

    Serial.print("Pack Voltage   : ");
    Serial.print(currentPackVoltage, 2);
    Serial.println(" V");

    Serial.print("SOC            : ");
    Serial.print(currentSOC, 1);
    Serial.println(" %");

    Serial.print("Imbalance      : ");
    Serial.print(currentImbalance, 2);
    Serial.println(" V");

    Serial.print("Weakest Cell   : ");
    Serial.println(currentWeakestCell);

    Serial.print("Strongest Cell : ");
    Serial.println(currentStrongestCell);

    Serial.print("Voltage Trend  : ");
    Serial.println(currentVoltageTrend);

    Serial.print("Imbalance Trend: ");
    Serial.println(currentImbalanceTrend);

    Serial.print("State          : ");
    Serial.println(stateName);

    Serial.print("Fault ID       : ");
    Serial.println(faultId);

    Serial.print("Risk Score     : ");
    Serial.print(currentRiskScore, 0);
    Serial.println(" / 100");

    Serial.print("Health         : ");
    Serial.println(currentHealthStatus);

    Serial.print("Fault Count    : ");
    Serial.println(faultCount);

    Serial.print("State Changes  : ");
    Serial.println(stateChangeCount);

    Serial.print("Recommendation : ");
    Serial.println(recommendation);

    Serial.println("----------------------------------------");
}


/* =========================================================
   TASK 6 EXECUTIVE SUMMARY
   ========================================================= */

void AnalyticsManager::printTask6ExecutiveSummary()
{
    float riskScore = getRiskScore();

    String recommendation =
        generateMaintenanceRecommendation(
            riskScore,
            currentImbalance,
            faultCount
        );

    Serial.println();
    Serial.println("========================================");
    Serial.println("       TASK 6 EXECUTIVE SUMMARY");
    Serial.println("========================================");

    Serial.print("Battery State       : ");
    Serial.println(currentStateName);

    Serial.print("Current Fault       : ");
    Serial.println(currentFaultId);

    Serial.print("Pack Voltage        : ");
    Serial.print(currentPackVoltage, 2);
    Serial.println(" V");

    Serial.print("SOC                 : ");
    Serial.print(currentSOC, 1);
    Serial.println(" %");

    Serial.print("Cell Imbalance      : ");
    Serial.print(currentImbalance, 2);
    Serial.println(" V");

    Serial.print("Risk Score          : ");
    Serial.print(riskScore, 0);
    Serial.println(" / 100");

    Serial.print("Health Status       : ");
    Serial.println(currentHealthStatus);

    Serial.print("Total Fault Events  : ");
    Serial.println(faultCount);

    Serial.print("State Transitions   : ");
    Serial.println(stateChangeCount);

    Serial.print("Maintenance Action  : ");
    Serial.println(recommendation);

    Serial.println("========================================");
}


/* =========================================================
   TASK 6 HISTORICAL TRENDS
   ========================================================= */

void AnalyticsManager::printTask6HistoricalTrends()
{
    Serial.println();
    Serial.println("========================================");
    Serial.println("       TASK 6 HISTORICAL TRENDS");
    Serial.println("========================================");

    Serial.print("Samples Stored      : ");
    Serial.println(historyCount);

    if (historyCount > 0)
    {
        float avgVoltage =
            calculateAverage(voltageHistory, historyCount);

        float avgSOC =
            calculateAverage(socHistory, historyCount);

        float avgImbalance =
            calculateAverage(imbalanceHistory, historyCount);

        float avgRisk =
            calculateAverage(riskHistory, historyCount);

        Serial.print("Average Voltage     : ");
        Serial.print(avgVoltage, 2);
        Serial.println(" V");

        Serial.print("Average SOC         : ");
        Serial.print(avgSOC, 1);
        Serial.println(" %");

        Serial.print("Average Imbalance   : ");
        Serial.print(avgImbalance, 2);
        Serial.println(" V");

        Serial.print("Average Risk        : ");
        Serial.print(avgRisk, 1);
        Serial.println(" / 100");
    }

    Serial.print("Voltage Trend       : ");
    Serial.println(currentVoltageTrend);

    Serial.print("Imbalance Trend     : ");
    Serial.println(currentImbalanceTrend);

    Serial.println("========================================");
}


/* =========================================================
   TASK 6 FAULT HISTORY
   ========================================================= */

void AnalyticsManager::printTask6FaultHistory()
{
    Serial.println();
    Serial.println("========================================");
    Serial.println("          TASK 6 FAULT HISTORY");
    Serial.println("========================================");

    if (faultHistoryCount == 0)
    {
        Serial.println("No faults recorded.");
        Serial.println("========================================");
        return;
    }

    int startIndex;

    if (faultHistoryCount < FAULT_HISTORY_SIZE)
    {
        startIndex = 0;
    }
    else
    {
        startIndex = faultHistoryIndex;
    }

    for (int i = 0; i < faultHistoryCount; i++)
    {
        int index =
            (startIndex + i) % FAULT_HISTORY_SIZE;

        Serial.print("#");
        Serial.print(i + 1);

        Serial.print(" | Time: ");
        Serial.print(faultHistory[index].timestamp);
        Serial.print(" s");

        Serial.print(" | State: ");
        Serial.print(faultHistory[index].stateName);

        Serial.print(" | Fault: ");
        Serial.print(faultHistory[index].faultId);

        Serial.print(" | Severity: ");
        Serial.println(faultHistory[index].severity);
    }

    Serial.println("========================================");
}


/* =========================================================
   TASK 6 DASHBOARD
   ========================================================= */

void AnalyticsManager::printTask6Dashboard()
{
    float riskScore = getRiskScore();

    String recommendation =
        generateMaintenanceRecommendation(
            riskScore,
            currentImbalance,
            faultCount
        );

    Serial.println();
    Serial.println("========================================");
    Serial.println("       ENTERPRISE DECISION DASHBOARD");
    Serial.println("========================================");

    Serial.print("STATE        : ");
    Serial.println(currentStateName);

    Serial.print("FAULT        : ");
    Serial.println(currentFaultId);

    Serial.print("HEALTH       : ");
    Serial.println(currentHealthStatus);

    Serial.print("RISK         : ");
    Serial.print(riskScore, 0);
    Serial.println(" / 100");

    Serial.print("SOC          : ");
    Serial.print(currentSOC, 1);
    Serial.println(" %");

    Serial.print("PACK VOLTAGE : ");
    Serial.print(currentPackVoltage, 2);
    Serial.println(" V");

    Serial.print("IMBALANCE    : ");
    Serial.print(currentImbalance, 2);
    Serial.println(" V");

    Serial.print("VOLT TREND   : ");
    Serial.println(currentVoltageTrend);

    Serial.print("IMBAL TREND  : ");
    Serial.println(currentImbalanceTrend);

    Serial.print("FAULT EVENTS : ");
    Serial.println(faultCount);

    Serial.print("TRANSITIONS  : ");
    Serial.println(stateChangeCount);

    Serial.print("ACTION       : ");
    Serial.println(recommendation);

    Serial.println("----------------------------------------");

    // Protection state and health override the numeric threshold.
    if (currentStateName == "SHUTDOWN")
    {
        Serial.println("DECISION: SHUTDOWN - CRITICAL");
    }
    else if (currentStateName == "FAILSAFE" ||
             currentHealthStatus == "CRITICAL" ||
             riskScore >= 80.0)
    {
        Serial.println("DECISION: CRITICAL - ACT NOW");
    }
    else if (currentStateName == "DEGRADED" ||
             riskScore >= 50.0)
    {
        Serial.println("DECISION: HIGH RISK - INSPECT");
    }
    else if (currentFaultId != "NONE" ||
             currentHealthStatus == "WARNING" ||
             riskScore >= 20.0)
    {
        Serial.println("DECISION: MONITOR");
    }
    else
    {
        Serial.println("DECISION: NORMAL OPERATION");
    }

    Serial.println("========================================");
}


/* =========================================================
   DASHBOARD ALIAS
   ========================================================= */

void AnalyticsManager::printDashboard()
{
    printTask6Dashboard();
}


/* =========================================================
   COMPLETE REPORT
   ========================================================= */

void AnalyticsManager::printReport()
{
    printTask6ExecutiveSummary();
    printTask6HistoricalTrends();
    printTask6FaultHistory();
    printTask6Dashboard();
}


/* =========================================================
   GET DATA
   ========================================================= */

AnalyticsData AnalyticsManager::getData()
{
    AnalyticsData data;

    data.packVoltage = currentPackVoltage;
    data.soc = currentSOC;
    data.imbalance = currentImbalance;

    data.minimumCellVoltage = currentMinimumCellVoltage;
    data.maximumCellVoltage = currentMaximumCellVoltage;

    data.weakestCell = currentWeakestCell;
    data.strongestCell = currentStrongestCell;

    data.sampleCount = sampleCount;
    data.faultCount = faultCount;
    data.stateChangeCount = stateChangeCount;
    data.uptimeSeconds = getUptimeSeconds();

    data.riskScore = currentRiskScore;

    data.batteryWarning =
        currentHealthStatus == "WARNING";

    data.criticalCondition =
        currentHealthStatus == "CRITICAL";

    data.severity = getSeverity();

    data.voltageTrend = currentVoltageTrend;
    data.imbalanceTrend = currentImbalanceTrend;
    data.healthStatus = currentHealthStatus;

    data.maintenanceRecommendation =
        getMaintenanceRecommendation();

    data.currentState = currentStateName;
    data.currentFaultId = currentFaultId;

    return data;
}


/* =========================================================
   GETTERS
   ========================================================= */

float AnalyticsManager::getRiskScore()
{
    return currentRiskScore;
}


unsigned long AnalyticsManager::getFaultCount()
{
    return faultCount;
}


unsigned long AnalyticsManager::getStateChangeCount()
{
    return stateChangeCount;
}


unsigned long AnalyticsManager::getUptimeSeconds()
{
    if (systemStartTime == 0)
    {
        return 0;
    }

    return (millis() - systemStartTime) / 1000;
}


AnalyticsSeverity AnalyticsManager::getSeverity()
{
    if (currentHealthStatus == "CRITICAL")
    {
        return ANALYTICS_CRITICAL;
    }

    if (currentHealthStatus == "WARNING")
    {
        return ANALYTICS_WARNING;
    }

    return ANALYTICS_NORMAL;
}


String AnalyticsManager::getHealthStatus()
{
    return currentHealthStatus;
}


String AnalyticsManager::getMaintenanceRecommendation()
{
    return generateMaintenanceRecommendation(
        currentRiskScore,
        currentImbalance,
        faultCount
    );
}


String AnalyticsManager::getCurrentState()
{
    return currentStateName;
}


String AnalyticsManager::getCurrentFaultId()
{
    return currentFaultId;
}


String AnalyticsManager::getVoltageTrend()
{
    return currentVoltageTrend;
}


String AnalyticsManager::getImbalanceTrend()
{
    return currentImbalanceTrend;
}


float AnalyticsManager::getCurrentSOC()
{
    return currentSOC;
}


float AnalyticsManager::getCurrentImbalance()
{
    return currentImbalance;
}


float AnalyticsManager::getCurrentPackVoltage()
{
    return currentPackVoltage;
}
