#include "BMS.h"
#include "Safety.h"
#include "LCDManager.h"
#include "FaultState.h"
#include "Telemetry.h"
#include "Analytics.h"

// ============================================================
// BATTERY CELL DATA
// ============================================================

float cellVoltage[NUM_CELLS] = {
    3.70f, 3.80f, 3.75f, 3.60f
};

float soc = 75.0f;          // Demo placeholder, not a real SOC estimate
float dischargeRate = 1.0f;

// ============================================================
// SYSTEM OBJECTS
// ============================================================

SafetyManager safety;
LCDManager lcdManager;
FaultStateManager faultState;
TelemetryManager telemetry;
AnalyticsManager analytics;

// ============================================================
// TIMING
// ============================================================

unsigned long previousTime = 0;
const unsigned long interval = 1000UL;

unsigned long demoStartTime = 0;
unsigned long lastTask6DashboardTime = 0;

const unsigned long TASK6_DASHBOARD_INTERVAL = 10000UL;

// ============================================================
// DEMO BATTERY CONDITIONS
// ============================================================

void updateDemoCells()
{
    unsigned long elapsed = millis() - demoStartTime;

    if (elapsed < 5000UL)
    {
        cellVoltage[0] = 3.70f;
        cellVoltage[1] = 3.80f;
        cellVoltage[2] = 3.75f;
        cellVoltage[3] = 3.60f;
        Serial.println("[DEMO] TEST 1: NORMAL");
    }
    else if (elapsed < 10000UL)
    {
        cellVoltage[0] = 3.70f;
        cellVoltage[1] = 3.80f;
        cellVoltage[2] = 3.75f;
        cellVoltage[3] = 5.80f;
        Serial.println("[DEMO] TEST 2: OVER-VOLTAGE");
    }
    else if (elapsed < 15000UL)
    {
        cellVoltage[0] = 3.70f;
        cellVoltage[1] = 3.80f;
        cellVoltage[2] = 3.75f;
        cellVoltage[3] = 5.20f;
        Serial.println("[DEMO] TEST 3: UNSAFE RECOVERY TEST");
    }
    else if (elapsed < 20000UL)
    {
        cellVoltage[0] = 3.70f;
        cellVoltage[1] = 3.80f;
        cellVoltage[2] = 3.75f;
        cellVoltage[3] = 3.60f;
        Serial.println("[DEMO] TEST 4: NORMAL RESTORED");
    }
    else if (elapsed < 25000UL)
    {
        for (int i = 0; i < NUM_CELLS; i++)
            cellVoltage[i] = 1.50f;

        Serial.println("[DEMO] TEST 5: UNDER-VOLTAGE");
    }
    else if (elapsed < 30000UL)
    {
        for (int i = 0; i < NUM_CELLS; i++)
            cellVoltage[i] = 3.20f;

        Serial.println("[DEMO] TEST 6: UNDER-VOLTAGE RECOVERY");
    }
    else if (elapsed < 35000UL)
    {
        cellVoltage[0] = 3.70f;
        cellVoltage[1] = 3.80f;
        cellVoltage[2] = 3.75f;
        cellVoltage[3] = 3.60f;
        Serial.println("[DEMO] TEST 7: NORMAL AFTER RECOVERY");
    }
    else if (elapsed < 40000UL)
    {
        cellVoltage[0] = 3.70f;
        cellVoltage[1] = 3.80f;
        cellVoltage[2] = 3.75f;
        cellVoltage[3] = 5.00f;
        Serial.println("[DEMO] TEST 8: UNREALISTIC VOLTAGE JUMP");
    }
    else if (elapsed < 45000UL)
    {
        cellVoltage[0] = 3.70f;
        cellVoltage[1] = 3.80f;
        cellVoltage[2] = 3.75f;
        cellVoltage[3] = 3.60f;
        Serial.println("[DEMO] TEST 9: FINAL NORMAL");
    }
    else
    {
        demoStartTime = millis();

        Serial.println();
        Serial.println("==============================");
        Serial.println("RESTARTING SAFETY TESTS");
        Serial.println("==============================");
    }
}

// ============================================================
// GET PRIMARY FAULT ID
// Keep this priority consistent with Safety.cpp.
// ============================================================

String getSafetyFaultId(const SafetyData &data)
{
    if (data.overVoltage)
        return "OVER_VOLTAGE";

    if (data.underVoltage)
        return "UNDER_VOLTAGE";

    if (data.sensorInvalid)
        return "SENSOR_INVALID";

    if (data.unrealisticJump)
        return "UNREALISTIC_JUMP";

    if (data.frozenReading)
        return "FROZEN_READING";

    if (data.noisySignal)
        return "NOISY_SIGNAL";

    return "NONE";
}

// ============================================================
// CHECK CRITICAL FAULT
// ============================================================

bool isCriticalFault(const SafetyData &data)
{
    return data.overVoltage ||
           data.underVoltage ||
           data.sensorInvalid ||
           data.frozenReading ||
           data.unrealisticJump;
}

// ============================================================
// EFFECTIVE SOFTWARE RELAY COMMAND
// ============================================================

bool isRelayAllowed(
    const SafetyData &data,
    FaultState state
)
{
    if (data.relayState != RELAY_ON)
        return false;

    if (data.faultDetected ||
        data.overVoltage ||
        data.underVoltage ||
        data.sensorInvalid ||
        data.frozenReading ||
        data.unrealisticJump)
    {
        return false;
    }

    if (state == STATE_FAILSAFE ||
        state == STATE_SHUTDOWN)
    {
        return false;
    }

    return true;
}

// ============================================================
// SETUP
// ============================================================

void setup()
{
    Serial.begin(115200);
    delay(200);

    Serial.println();
    Serial.println("================================");
    Serial.println("       BMS SYSTEM STARTED");
    Serial.println("================================");

    Serial.print("Number of Cells: ");
    Serial.println(NUM_CELLS);

    safety.begin();
    lcdManager.begin();
    faultState.begin();
    telemetry.begin();
    analytics.begin();

    demoStartTime = millis();
    lastTask6DashboardTime = millis();
    previousTime = millis();

    Serial.println("[SYSTEM] BMS       : READY");
    Serial.println("[SYSTEM] SAFETY    : READY");
    Serial.println("[SYSTEM] LCD       : READY");
    Serial.println("[SYSTEM] FAULT     : READY");
    Serial.println("[SYSTEM] TELEMETRY : READY");
    Serial.println("[SYSTEM] ANALYTICS  : READY");
    Serial.println();
    Serial.println("[SYSTEM] Monitoring started...");
}

// ============================================================
// MAIN LOOP
// ============================================================

void loop()
{
    unsigned long currentTime = millis();

    if (currentTime - previousTime < interval)
        return;

    previousTime = currentTime;

    // 1. Update simulated cell readings.
    updateDemoCells();

    // 2. Analyze battery data.
    BMSData result = analyzeBattery(
        cellVoltage,
        soc,
        dischargeRate
    );

    // 3. Calculate pack voltage.
    float packVoltage = 0.0f;

    for (int i = 0; i < NUM_CELLS; i++)
        packVoltage += cellVoltage[i];

    // 4. Run safety checks.
    SafetyData safetyResult = safety.update(
        packVoltage,
        cellVoltage,
        NUM_CELLS
    );

    // Use the safety manager's primary fault ID when available.
    String faultId = getSafetyFaultId(safetyResult);

    if (safetyResult.faultId != "NONE")
        faultId = safetyResult.faultId;

    bool criticalFault = isCriticalFault(safetyResult);

    // 5. Never tell the fault manager the relay is ON
    // while safety protection is active.
    bool relayOn =
        safetyResult.relayState == RELAY_ON &&
        !safetyResult.faultDetected &&
        !safetyResult.overVoltage &&
        !safetyResult.underVoltage &&
        !safetyResult.sensorInvalid &&
        !safetyResult.frozenReading &&
        !safetyResult.unrealisticJump;

    // 6. Update the fault-state machine.
    FaultState currentFaultState = faultState.update(
        safetyResult.faultDetected,
        criticalFault,
        relayOn,
        faultId,
        packVoltage
    );

    // 7. Determine final software relay command.
    bool relayAllowed = isRelayAllowed(
        safetyResult,
        currentFaultState
    );

    // 8. Update telemetry.
    telemetry.update(
        result,
        safetyResult,
        currentFaultState,
        faultState.getStateName(),
        faultState.getFaultId(),
        packVoltage,
        cellVoltage
    );

    // 9. Update analytics.
    analytics.update(
        result,
        safetyResult,
        currentFaultState,
        faultState.getStateName(),
        faultState.getFaultId(),
        packVoltage
    );

    // 10. Periodic dashboard.
    if (currentTime - lastTask6DashboardTime >=
        TASK6_DASHBOARD_INTERVAL)
    {
        lastTask6DashboardTime = currentTime;
        analytics.printTask6Dashboard();
    }

    // ========================================================
    // BMS STATUS
    // ========================================================

    Serial.println();
    Serial.println("---------- BMS STATUS ----------");

    for (int i = 0; i < NUM_CELLS; i++)
    {
        Serial.print("Cell ");
        Serial.print(i + 1);
        Serial.print(": ");
        Serial.print(cellVoltage[i], 2);
        Serial.println(" V");
    }

    Serial.print("Pack Voltage: ");
    Serial.print(packVoltage, 2);
    Serial.println(" V");

    Serial.print("Weakest Cell: ");
    Serial.println(result.weakestCell + 1);

    Serial.print("Strongest Cell: ");
    Serial.println(result.strongestCell + 1);

    Serial.print("Imbalance: ");
    Serial.print(result.imbalance, 2);
    Serial.println(" V");

    Serial.print("Trend: ");
    Serial.println(result.trend);

    if (result.imbalanceWarning)
        Serial.println("WARNING: HIGH CELL IMBALANCE!");

    // ========================================================
    // SAFETY STATUS
    // ========================================================

    Serial.println();
    Serial.println("-------- SAFETY STATUS --------");

    Serial.print("Safety Relay State: ");

    if (safetyResult.relayState == RELAY_ON)
        Serial.println("ON");
    else if (safetyResult.relayState == RELAY_FAULT)
        Serial.println("FAULT");
    else
        Serial.println("OFF");

    Serial.print("Effective Relay Command: ");
    Serial.println(relayAllowed ? "ON" : "OFF");

    if (safetyResult.overVoltage)
        Serial.println("FAULT: OVER VOLTAGE");

    if (safetyResult.underVoltage)
        Serial.println("FAULT: UNDER VOLTAGE");

    if (safetyResult.sensorInvalid)
        Serial.println("FAULT: SENSOR INVALID");

    if (safetyResult.frozenReading)
        Serial.println("FAULT: FROZEN READING");

    if (safetyResult.unrealisticJump)
        Serial.println("FAULT: UNREALISTIC JUMP");

    if (safetyResult.noisySignal)
        Serial.println("WARNING: NOISY SIGNAL");

    // ========================================================
    // FAULT STATE
    // ========================================================

    Serial.println();
    Serial.println("-------- FAULT STATE --------");

    Serial.print("Current State: ");
    Serial.println(faultState.getStateName());

    Serial.print("Fault ID: ");
    Serial.println(faultState.getFaultId());

    Serial.println("-----------------------------");

    // ========================================================
    // LCD UPDATE
    // ========================================================

    lcdManager.update(
        result,
        safetyResult,
        faultState.getStateName(),
        faultState.getFaultId()
    );
}
