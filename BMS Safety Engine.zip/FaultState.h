#ifndef FAULT_STATE_H
#define FAULT_STATE_H

#include <Arduino.h>

// =====================================================
// FAULT STATE MACHINE
// =====================================================

enum FaultState
{
    STATE_NORMAL,
    STATE_DEGRADED,
    STATE_FAILSAFE,
    STATE_SHUTDOWN
};

// =====================================================
// FAULT EVENT DATA
// =====================================================

struct FaultEvent
{
    FaultState previousState;
    FaultState newState;

    String faultId;

    unsigned long timestamp;

    float packVoltage;

    bool relayOn;
};

// =====================================================
// FAULT STATE MANAGER
// =====================================================

class FaultStateManager
{
private:

    FaultState currentState;
    FaultState previousState;

    String currentFault;

    unsigned long stateChangeTime;

    // Time for persistent critical fault
    unsigned long criticalFaultStartTime;

    // Time required before shutdown
    const unsigned long SHUTDOWN_DELAY = 5000;

    // Time required for verified recovery
    const unsigned long RECOVERY_DELAY = 3000;

    FaultEvent lastEvent;

    // -------------------------------------------------
    // STATE CHANGE
    // -------------------------------------------------

    void changeState(
        FaultState newState,
        String faultId,
        float packVoltage,
        bool relayOn
    );

public:

    FaultStateManager();

    void begin();

    FaultState update(
        bool faultDetected,
        bool criticalFault,
        bool relayOn,
        String faultId,
        float packVoltage
    );

    FaultState getState();

    String getStateName();

    String getFaultId();

    FaultEvent getLastEvent();
};

#endif