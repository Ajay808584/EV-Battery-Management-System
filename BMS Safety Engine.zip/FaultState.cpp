#include "FaultState.h"

// =====================================================
// CONSTRUCTOR
// =====================================================

FaultStateManager::FaultStateManager()
{
    currentState = STATE_NORMAL;
    previousState = STATE_NORMAL;

    currentFault = "NONE";

    stateChangeTime = 0;
    criticalFaultStartTime = 0;

    lastEvent.previousState = STATE_NORMAL;
    lastEvent.newState = STATE_NORMAL;
    lastEvent.faultId = "NONE";
    lastEvent.timestamp = 0;
    lastEvent.packVoltage = 0.0;
    lastEvent.relayOn = true;
}

// =====================================================
// INITIALIZATION
// =====================================================

void FaultStateManager::begin()
{
    currentState = STATE_NORMAL;
    previousState = STATE_NORMAL;

    currentFault = "NONE";

    stateChangeTime = millis();
    criticalFaultStartTime = 0;

    Serial.println();
    Serial.println("================================");
    Serial.println("   FAULT STATE MACHINE STARTED");
    Serial.println("================================");
}

// =====================================================
// STATE CHANGE
// =====================================================

void FaultStateManager::changeState(
    FaultState newState,
    String faultId,
    float packVoltage,
    bool relayOn
)
{
    if (newState == currentState)
    {
        return;
    }

    previousState = currentState;
    currentState = newState;
    currentFault = faultId;

    stateChangeTime = millis();

    // Store transition event
    lastEvent.previousState = previousState;
    lastEvent.newState = currentState;
    lastEvent.faultId = faultId;
    lastEvent.timestamp = stateChangeTime;
    lastEvent.packVoltage = packVoltage;
    lastEvent.relayOn = relayOn;

    // -------------------------------------------------
    // SERIAL LOG
    // -------------------------------------------------

    Serial.println();
    Serial.println("[STATE] State transition detected");

    Serial.print("[STATE] ");

    if (previousState == STATE_NORMAL)
    {
        Serial.print("NORMAL");
    }
    else if (previousState == STATE_DEGRADED)
    {
        Serial.print("DEGRADED");
    }
    else if (previousState == STATE_FAILSAFE)
    {
        Serial.print("FAILSAFE");
    }
    else
    {
        Serial.print("SHUTDOWN");
    }

    Serial.print(" -> ");

    if (currentState == STATE_NORMAL)
    {
        Serial.println("NORMAL");
    }
    else if (currentState == STATE_DEGRADED)
    {
        Serial.println("DEGRADED");
    }
    else if (currentState == STATE_FAILSAFE)
    {
        Serial.println("FAILSAFE");
    }
    else
    {
        Serial.println("SHUTDOWN");
    }

    Serial.print("[STATE] Fault ID: ");
    Serial.println(faultId);

    Serial.print("[STATE] Timestamp: ");
    Serial.print(stateChangeTime);
    Serial.println(" ms");

    Serial.print("[STATE] Pack Voltage: ");
    Serial.print(packVoltage, 2);
    Serial.println(" V");

    Serial.print("[STATE] Relay: ");

    if (relayOn)
    {
        Serial.println("ON");
    }
    else
    {
        Serial.println("OFF");
    }
}

// =====================================================
// UPDATE STATE MACHINE
// =====================================================

FaultState FaultStateManager::update(
    bool faultDetected,
    bool criticalFault,
    bool relayOn,
    String faultId,
    float packVoltage
)
{
    unsigned long currentTime = millis();

    // =================================================
    // SHUTDOWN STATE
    // =================================================

    if (currentState == STATE_SHUTDOWN)
    {
        // Recovery is allowed only when:
        //
        // 1. No fault is detected
        // 2. No critical fault exists
        // 3. Safety relay is ON
        // 4. Recovery delay has elapsed

        if (!faultDetected &&
            !criticalFault &&
            relayOn)
        {
            if (currentTime - stateChangeTime >= RECOVERY_DELAY)
            {
                Serial.println();
                Serial.println(
                    "[STATE] Shutdown recovery verified"
                );

                changeState(
                    STATE_NORMAL,
                    "NONE",
                    packVoltage,
                    relayOn
                );

                criticalFaultStartTime = 0;
            }
        }
        else
        {
            // Keep active fault information
            // while shutdown conditions remain.

            if (faultDetected || criticalFault)
            {
                currentFault = faultId;
            }
        }

        return currentState;
    }

    // =================================================
    // CRITICAL FAULT
    // =================================================

    if (criticalFault)
    {
        if (currentState != STATE_FAILSAFE)
        {
            changeState(
                STATE_FAILSAFE,
                faultId,
                packVoltage,
                relayOn
            );

            criticalFaultStartTime = currentTime;
        }
        else
        {
            currentFault = faultId;

            // Persistent critical fault
            if (currentTime - criticalFaultStartTime >= SHUTDOWN_DELAY)
            {
                changeState(
                    STATE_SHUTDOWN,
                    faultId,
                    packVoltage,
                    relayOn
                );
            }
        }

        return currentState;
    }

    // =================================================
    // NORMAL FAULT
    // =================================================

    if (faultDetected)
    {
        // ---------------------------------------------
        // NORMAL -> DEGRADED
        // ---------------------------------------------

        if (currentState == STATE_NORMAL)
        {
            changeState(
                STATE_DEGRADED,
                faultId,
                packVoltage,
                relayOn
            );
        }

        // ---------------------------------------------
        // DEGRADED -> FAILSAFE
        // ---------------------------------------------

        else if (currentState == STATE_DEGRADED)
        {
            changeState(
                STATE_FAILSAFE,
                faultId,
                packVoltage,
                relayOn
            );

            criticalFaultStartTime = currentTime;
        }

        // ---------------------------------------------
        // FAILSAFE: UPDATE FAULT ID
        // ---------------------------------------------

        else if (currentState == STATE_FAILSAFE)
        {
            currentFault = faultId;
        }

        return currentState;
    }

    // =================================================
    // NO ACTIVE FAULT
    // =================================================

    if (!faultDetected && !criticalFault)
    {
        // ---------------------------------------------
        // DEGRADED STATE
        // ---------------------------------------------
        //
        // IMPORTANT:
        //
        // Do NOT immediately change DEGRADED -> NORMAL.
        //
        // SafetyManager may have cleared the fault,
        // but the relay can still be OFF while recovery
        // verification is in progress.
        //
        // NORMAL is allowed only when relay is ON.

        if (currentState == STATE_DEGRADED)
        {
            if (relayOn)
            {
                changeState(
                    STATE_NORMAL,
                    "NONE",
                    packVoltage,
                    relayOn
                );

                criticalFaultStartTime = 0;
            }
            else
            {
                // Keep DEGRADED while relay remains OFF.
                //
                // Keep the previous fault ID so that
                // telemetry and analytics still know
                // which fault caused the degraded state.

                return currentState;
            }
        }

        // ---------------------------------------------
        // FAILSAFE RECOVERY
        // ---------------------------------------------

        else if (currentState == STATE_FAILSAFE)
        {
            // Relay MUST be ON before recovery
            // can begin/complete.

            if (relayOn)
            {
                if (currentTime - stateChangeTime >= RECOVERY_DELAY)
                {
                    Serial.println();
                    Serial.println(
                        "[STATE] Recovery verified"
                    );

                    changeState(
                        STATE_NORMAL,
                        "NONE",
                        packVoltage,
                        relayOn
                    );

                    criticalFaultStartTime = 0;
                }
            }
            else
            {
                // -------------------------------------------------
                // SAFETY RECOVERY NOT COMPLETE
                // -------------------------------------------------
                //
                // Fault has disappeared, but SafetyManager
                // has not yet turned the relay ON.
                //
                // Keep FAILSAFE and preserve the fault ID.
                //

                return currentState;
            }
        }

        return currentState;
    }

    return currentState;
}

// =====================================================
// GET CURRENT STATE
// =====================================================

FaultState FaultStateManager::getState()
{
    return currentState;
}

// =====================================================
// GET STATE NAME
// =====================================================

String FaultStateManager::getStateName()
{
    if (currentState == STATE_NORMAL)
    {
        return "NORMAL";
    }

    if (currentState == STATE_DEGRADED)
    {
        return "DEGRADED";
    }

    if (currentState == STATE_FAILSAFE)
    {
        return "FAILSAFE";
    }

    if (currentState == STATE_SHUTDOWN)
    {
        return "SHUTDOWN";
    }

    return "UNKNOWN";
}

// =====================================================
// GET CURRENT FAULT
// =====================================================

String FaultStateManager::getFaultId()
{
    return currentFault;
}

// =====================================================
// GET LAST EVENT
// =====================================================

FaultEvent FaultStateManager::getLastEvent()
{
    return lastEvent;
}
