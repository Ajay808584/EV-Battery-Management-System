#ifndef LCDMANAGER_H
#define LCDMANAGER_H

#include <Arduino.h>
#include <LiquidCrystal_I2C.h>

#include "BMS.h"
#include "Safety.h"

class LCDManager
{
private:

    LiquidCrystal_I2C lcd;

    int currentPage;

    unsigned long lastPageChange;

    // Change LCD page every 3 seconds
    const unsigned long PAGE_INTERVAL = 3000;

    // Cached LCD lines
    // Used to prevent unnecessary LCD writes/flicker
    String lastLine1;
    String lastLine2;

    // TRUE while FAILSAFE/SHUTDOWN is being displayed
    bool criticalFaultShown;

    // Update only when LCD content actually changes
    void updateLine(int row, String text);

    // Normal display pages
    void showPage1(const BMSData &bmsData);
    void showPage2(const BMSData &bmsData);
    void showPage3(const SafetyData &safetyData);

    // Critical fault display
    void showCriticalFault(
        const String &faultId,
        const String &stateName
    );

public:

    LCDManager();

    // Initialize LCD
    void begin();

    // Main LCD update
    void update(
        const BMSData &bmsData,
        const SafetyData &safetyData,
        const String &stateName,
        const String &faultId
    );

    // Clear critical-fault display state
    void clearCriticalFault();
};

#endif